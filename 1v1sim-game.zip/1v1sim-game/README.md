# 1v1 Simulator

A browser-based 1v1 combat game with 9 modes, bot matches, stats, and matchmaking.

## ▶ How to Play Online (No Localhost Needed)

### Option 1 — Netlify Drop (Easiest, Free)
1. Go to https://app.netlify.com/drop
2. Drag and drop this entire folder onto the page
3. Done! You get a live URL instantly (e.g. `https://random-name.netlify.app`)

### Option 2 — GitHub Pages (Free)
1. Create a new repo on https://github.com
2. Upload `index.html` to the repo
3. Go to Settings → Pages → Source: main branch
4. Your game is live at `https://yourusername.github.io/repo-name`

### Option 3 — itch.io (Great for games)
1. Go to https://itch.io/game/new
2. Set "Kind of project" to HTML
3. Upload this ZIP file directly
4. Publish!

### Option 4 — Vercel (Free)
1. Go to https://vercel.com
2. Import your GitHub repo or drag-drop
3. Instant live URL

## Controls
- **Click / Space** — Basic attack
- **Q / W / E** — Use abilities
- **A/D or Arrow Keys** — Move
- **Mouse Click** on canvas — Attack

## Game Modes
- Classic, Stick, UHC, Potion, Food, Fruit, Mace, Bedfight, Combo

## Features
- Bot matches (Easy / Medium / Hard)
- Simulated PvP matchmaking queue
- Kill/Win/Streak stats saved in browser
- Combo system, abilities with cooldowns
- Damage numbers, particles, HP bars
